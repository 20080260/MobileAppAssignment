package org.wit.player.models

import android.os.Parcelable
import kotlinx.android.parcel.Parcelize

@Parcelize
data class PlayerModel (var id: Long =0,
                           var name: String = "",
                           var age: String = "",
                           var position: String= "",
                           var club: String = "",
                           var nationality: String = "",
                           var kitnumber: String = "",
                           var image: String = "") : Parcelable {
}