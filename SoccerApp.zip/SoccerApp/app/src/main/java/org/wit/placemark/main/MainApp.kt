package org.wit.player.main

import android.app.Application
import org.jetbrains.anko.AnkoLogger
import org.jetbrains.anko.info
import org.wit.placemark.models.PlacemarkMemStore
import org.wit.placemark.models.PlacemarkModel

class MainApp: Application(), AnkoLogger {

    //val player = ArrayList<PlayerModel>()
    val players = PlayerMemStore()

    override fun onCreate() {
        super.onCreate()
        info("Player Started")
        //players.add(PlayerModel("One", "About one..."))
        //players.add(PlayerModel("Two", "About two..."))
        //players.add(PlayerModel("Three", "About three..."))
    }
}