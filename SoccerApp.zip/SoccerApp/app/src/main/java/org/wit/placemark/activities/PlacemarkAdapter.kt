package org.wit.player;

import android.support.v7.widget.RecyclerView
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import kotlinx.android.synthetic.main.activity_placemark.view.*
import kotlinx.android.synthetic.main.card_placemark.view.*
import org.wit.placemark.R
import org.wit.placemark.models.PlacemarkModel

interface PlayerListener {
    fun onPlayerClick(player: PlayerModel)
}

class PlayerAdapter constructor(private var players: List<PlayerModel>,
                                   private val listener: PlayerListener) : RecyclerView.Adapter<PlayerAdapter.MainHolder>() {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): MainHolder {
        return MainHolder(LayoutInflater.from(parent?.context).inflate(R.layout.card_player, parent, false))
    }

    override fun onBindViewHolder(holder: MainHolder, position: Int) {
        val player = players[holder.adapterPosition]
        holder.bind(player, listener)
    }

    override fun getItemCount(): Int = player.size

    class MainHolder constructor(itemView: View) : RecyclerView.ViewHolder(itemView) {

        fun bind(player: PlayerModel,  listener : PlayerListener) {
            itemView.playerNameList.text= player.Name
            itemView.playerAgeList.text = player.Age
            itemView.playerPositionList.text = player.position
            itemView.playerClubList.text = player.club
            itemView.playerNationalityList.text = player.nationality
            itemView.playerKitNumber.text - player.kitnumber
            itemView.setOnClickListener { listener.onPlayerClick(player) }
        }
    }
}
