package org.wit.player.activities

import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.view.Menu
import android.view.MenuItem
import kotlinx.android.synthetic.main.activity_placemark.*
import kotlinx.android.synthetic.main.activity_placemark_list.*
import kotlinx.android.synthetic.main.card_placemark.*
import org.jetbrains.anko.AnkoLogger
import org.jetbrains.anko.info
import org.jetbrains.anko.startActivityForResult
import org.jetbrains.anko.toast
import org.wit.placemark.R
import org.wit.placemark.main.MainApp
import org.wit.placemark.models.PlacemarkModel

class PlayerActivity : AppCompatActivity(), AnkoLogger {

    var player = PlayerModel()
    lateinit var app: MainApp

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_player)
        app = application as MainApp

        if (intent.hasExtra("player_edit"))
        {
            player = intent.extras.getParcelable<PlayerModel>("player_edit")
            playerName.setText(player.name)
            playerAge.setText(player.age)
            playerPosition.setText(player.position)
            playerClub.setText(player.club)
            playerNationality.setText(player.nationality)
            playerKitNumber.setText(player.kitnumber)
        }

        btnAddPlayer.setOnClickListener() {
            player.name = playerName.text.toString()
            player.age = playerAge.text.toString()
            player.position = playerPosition.text.toString()
            player.club = playerClub.text.toString()
            player.nationality = playerNationality.text.toString()
            player.kitnumber = playerKitNumber.text.toString()
            if (player.Name.isNotEmpty()) {
                app.players.create(player.copy())
                info("Add Button Pressed. name: ${player.name}")
                setResult(AppCompatActivity.RESULT_OK)
                finish()
            }
            else {
                toast ("Please enter a name")
            }
        }

        //Add action bar and set title
        toolbarAdd.name = name
        setSupportActionBar(toolbarAdd)

        val IMAGE_REQUEST = 1

        chooseImage.setOnClickListener {
            showImagePicker(this, IMAGE_REQUEST)


        }
    }

    override fun onCreateOptionsMenu(menu: Menu?): Boolean {
        menuInflater.inflate(R.menu.menu_player, menu)
        return super.onCreateOptionsMenu(menu)
    }


    override fun onOptionsItemSelected(item: MenuItem?): Boolean {
        when (item?.itemId) {
            R.id.item_cancel-> finish()
        }
        return super.onOptionsItemSelected(item)
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        when (requestCode) {
            IMAGE_REQUEST -> {
                if (data != null) {
                    player.image = data.getData().toString()
                    playerImage.setImageBitmap(readImage(this, resultCode, data))
                }
                if (intent.hasExtra("player_edit")) {
                    //... as before
                    playerImage.setImageBitmap(readImageFromPath(this, player.image))
                }
                }
            }
        }
    }


}
