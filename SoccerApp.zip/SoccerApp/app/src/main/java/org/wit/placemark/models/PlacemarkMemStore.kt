package org.wit.player.models

import org.jetbrains.anko.AnkoLogger
import org.jetbrains.anko.info

var lastId = 0L

internal fun getId(): Long {
    return lastId++
}

class PlayerMemStore : PlayerStore, AnkoLogger {

    val players = ArrayList<PlayerModel>()

    override fun findAll(): List<PlayerModel> {
        return players
    }

    override fun create(player: PlayerModel) {
        player.id = getId()
        players.add(player)
        logAll()
    }

    override fun update(player: PlayerModel) {
        var foundPlayer: PlayerModel? = players.find { p -> p.id == player.id }
        if (foundPlayer != null) {
            foundPlayer.name = player.name
            foundPlayer.age = player.age
            foundPlayer.position = player.position
            foundPlayer.club = player.club
            foundPlayer.nationality = player.nationality
            foundPlayer.kitnumber = player.kitnumber
            logAll()
        }
    }

    fun logAll() {
        players.forEach { info("${it}") }
    }
}
